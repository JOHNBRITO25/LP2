﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmenus
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            {
                int num1 = Convert.ToInt32(txtMenornumero.Text), num2 = Convert.ToInt32(txtMaiornumero.Text);

                if (num2 > num1)
                {
                    Random sorteio = new Random();
                    int numSorteado = sorteio.Next(num1, num2);

                    MessageBox.Show("O número sorteado é: " + numSorteado);
                }

                else
                {
                    MessageBox.Show("Insira um intervalo válido!");
                }
            }
        }
    }
}
