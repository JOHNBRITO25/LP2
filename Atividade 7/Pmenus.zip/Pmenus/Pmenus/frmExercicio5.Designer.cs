﻿namespace Pmenus
{
    partial class frmExercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSortear = new System.Windows.Forms.Button();
            this.txtMaiornumero = new System.Windows.Forms.TextBox();
            this.txtMenornumero = new System.Windows.Forms.TextBox();
            this.lblPalavra2 = new System.Windows.Forms.Label();
            this.lblPalavra1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnSortear
            // 
            this.btnSortear.BackColor = System.Drawing.SystemColors.Window;
            this.btnSortear.Location = new System.Drawing.Point(143, 163);
            this.btnSortear.Name = "btnSortear";
            this.btnSortear.Size = new System.Drawing.Size(93, 40);
            this.btnSortear.TabIndex = 11;
            this.btnSortear.Text = "Sortear";
            this.btnSortear.UseVisualStyleBackColor = false;
            this.btnSortear.Click += new System.EventHandler(this.btnSortear_Click);
            // 
            // txtMaiornumero
            // 
            this.txtMaiornumero.Location = new System.Drawing.Point(171, 114);
            this.txtMaiornumero.Name = "txtMaiornumero";
            this.txtMaiornumero.Size = new System.Drawing.Size(100, 20);
            this.txtMaiornumero.TabIndex = 10;
            // 
            // txtMenornumero
            // 
            this.txtMenornumero.Location = new System.Drawing.Point(171, 77);
            this.txtMenornumero.Name = "txtMenornumero";
            this.txtMenornumero.Size = new System.Drawing.Size(100, 20);
            this.txtMenornumero.TabIndex = 9;
            // 
            // lblPalavra2
            // 
            this.lblPalavra2.AutoEllipsis = true;
            this.lblPalavra2.AutoSize = true;
            this.lblPalavra2.Location = new System.Drawing.Point(77, 121);
            this.lblPalavra2.Name = "lblPalavra2";
            this.lblPalavra2.Size = new System.Drawing.Size(73, 13);
            this.lblPalavra2.TabIndex = 8;
            this.lblPalavra2.Text = "Maior Número";
            // 
            // lblPalavra1
            // 
            this.lblPalavra1.AutoSize = true;
            this.lblPalavra1.Location = new System.Drawing.Point(77, 80);
            this.lblPalavra1.Name = "lblPalavra1";
            this.lblPalavra1.Size = new System.Drawing.Size(77, 13);
            this.lblPalavra1.TabIndex = 7;
            this.lblPalavra1.Text = "Menor Número";
            // 
            // frmExercicio5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(412, 310);
            this.Controls.Add(this.btnSortear);
            this.Controls.Add(this.txtMaiornumero);
            this.Controls.Add(this.txtMenornumero);
            this.Controls.Add(this.lblPalavra2);
            this.Controls.Add(this.lblPalavra1);
            this.Name = "frmExercicio5";
            this.Text = "frmExercicio5";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSortear;
        private System.Windows.Forms.TextBox txtMaiornumero;
        private System.Windows.Forms.TextBox txtMenornumero;
        private System.Windows.Forms.Label lblPalavra2;
        private System.Windows.Forms.Label lblPalavra1;
    }
}