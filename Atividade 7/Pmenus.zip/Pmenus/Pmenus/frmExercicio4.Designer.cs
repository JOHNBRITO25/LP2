﻿namespace Pmenus
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnQtdeNum = new System.Windows.Forms.Button();
            this.btnEspacoBranco = new System.Windows.Forms.Button();
            this.btnQtdeLetras = new System.Windows.Forms.Button();
            this.rchTexto = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btnQtdeNum
            // 
            this.btnQtdeNum.BackColor = System.Drawing.SystemColors.Window;
            this.btnQtdeNum.Location = new System.Drawing.Point(271, 165);
            this.btnQtdeNum.Name = "btnQtdeNum";
            this.btnQtdeNum.Size = new System.Drawing.Size(97, 52);
            this.btnQtdeNum.TabIndex = 13;
            this.btnQtdeNum.Text = "Quantidade de Números";
            this.btnQtdeNum.UseVisualStyleBackColor = false;
            this.btnQtdeNum.Click += new System.EventHandler(this.btnInserirAsteriscos_Click);
            // 
            // btnEspacoBranco
            // 
            this.btnEspacoBranco.BackColor = System.Drawing.SystemColors.Window;
            this.btnEspacoBranco.Location = new System.Drawing.Point(175, 165);
            this.btnEspacoBranco.Name = "btnEspacoBranco";
            this.btnEspacoBranco.Size = new System.Drawing.Size(90, 52);
            this.btnEspacoBranco.TabIndex = 12;
            this.btnEspacoBranco.Text = "Primeiro Espaço em Branco";
            this.btnEspacoBranco.UseVisualStyleBackColor = false;
            this.btnEspacoBranco.Click += new System.EventHandler(this.btnInserir_Click);
            // 
            // btnQtdeLetras
            // 
            this.btnQtdeLetras.BackColor = System.Drawing.SystemColors.Window;
            this.btnQtdeLetras.Location = new System.Drawing.Point(76, 165);
            this.btnQtdeLetras.Name = "btnQtdeLetras";
            this.btnQtdeLetras.Size = new System.Drawing.Size(93, 52);
            this.btnQtdeLetras.TabIndex = 11;
            this.btnQtdeLetras.Text = "Quantidade de Letras";
            this.btnQtdeLetras.UseVisualStyleBackColor = false;
            this.btnQtdeLetras.Click += new System.EventHandler(this.btnTestar_Click);
            // 
            // rchTexto
            // 
            this.rchTexto.Location = new System.Drawing.Point(76, 25);
            this.rchTexto.Name = "rchTexto";
            this.rchTexto.Size = new System.Drawing.Size(292, 134);
            this.rchTexto.TabIndex = 14;
            this.rchTexto.Text = "";
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(461, 312);
            this.Controls.Add(this.rchTexto);
            this.Controls.Add(this.btnQtdeNum);
            this.Controls.Add(this.btnEspacoBranco);
            this.Controls.Add(this.btnQtdeLetras);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnQtdeNum;
        private System.Windows.Forms.Button btnEspacoBranco;
        private System.Windows.Forms.Button btnQtdeLetras;
        private System.Windows.Forms.RichTextBox rchTexto;
    }
}