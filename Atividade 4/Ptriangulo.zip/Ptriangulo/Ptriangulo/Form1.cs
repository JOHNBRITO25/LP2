﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        double A, B, C;

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtA.Clear();
            txtB.Clear();
            txtC.Clear();
            txtResul.Clear();

            txtA.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(txtA.Text, out A) && Double.TryParse(txtB.Text, out B) && Double.TryParse(txtC.Text, out C))
            {
                if (A < (B + C) && A > Math.Abs(B - C) && B < (A + C) && B > Math.Abs(A - C) && C < (A + B) && C > Math.Abs(A - B))
                {
                    if (A == B && B == C)
                    {
                        this.txtResul.Text = ("Triângulo Equilátero");
                    }
                    else
                    {
                        if (A == B || B == C || C == A)
                        {
                            this.txtResul.Text = ("Triângulo Isóceles");
                        }
                        else
                        {
                            this.txtResul.Text = ("Triângulo Escaleno");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Não existe Triângulo");
                }
            }
            else
            { 
                MessageBox.Show("Os valores devem ser numéricos");
            }
        }
    }
}
