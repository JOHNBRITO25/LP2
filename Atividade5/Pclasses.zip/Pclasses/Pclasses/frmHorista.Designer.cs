﻿namespace Pclasses
{
    partial class frmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbxHome = new System.Windows.Forms.GroupBox();
            this.rbtnNao = new System.Windows.Forms.RadioButton();
            this.rbtnSim = new System.Windows.Forms.RadioButton();
            this.btnInstanciar = new System.Windows.Forms.Button();
            this.txtDataentrada = new System.Windows.Forms.TextBox();
            this.txtSalario = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.lblDataentradanaempresa = new System.Windows.Forms.Label();
            this.lblSalariohora = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblMatricula = new System.Windows.Forms.Label();
            this.txtNumhoras = new System.Windows.Forms.TextBox();
            this.lblNumhoras = new System.Windows.Forms.Label();
            this.txtDiasdefalta = new System.Windows.Forms.TextBox();
            this.lblDiasdefalta = new System.Windows.Forms.Label();
            this.gbxHome.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbxHome
            // 
            this.gbxHome.Controls.Add(this.rbtnNao);
            this.gbxHome.Controls.Add(this.rbtnSim);
            this.gbxHome.Location = new System.Drawing.Point(486, 33);
            this.gbxHome.Name = "gbxHome";
            this.gbxHome.Size = new System.Drawing.Size(151, 100);
            this.gbxHome.TabIndex = 21;
            this.gbxHome.TabStop = false;
            this.gbxHome.Text = "Trabalhar em Home Office";
            // 
            // rbtnNao
            // 
            this.rbtnNao.AutoSize = true;
            this.rbtnNao.Location = new System.Drawing.Point(16, 60);
            this.rbtnNao.Name = "rbtnNao";
            this.rbtnNao.Size = new System.Drawing.Size(48, 17);
            this.rbtnNao.TabIndex = 1;
            this.rbtnNao.TabStop = true;
            this.rbtnNao.Text = "NÃO";
            this.rbtnNao.UseVisualStyleBackColor = true;
            // 
            // rbtnSim
            // 
            this.rbtnSim.AutoSize = true;
            this.rbtnSim.Location = new System.Drawing.Point(16, 37);
            this.rbtnSim.Name = "rbtnSim";
            this.rbtnSim.Size = new System.Drawing.Size(44, 17);
            this.rbtnSim.TabIndex = 0;
            this.rbtnSim.TabStop = true;
            this.rbtnSim.Text = "SIM";
            this.rbtnSim.UseVisualStyleBackColor = true;
            // 
            // btnInstanciar
            // 
            this.btnInstanciar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInstanciar.Location = new System.Drawing.Point(269, 340);
            this.btnInstanciar.Name = "btnInstanciar";
            this.btnInstanciar.Size = new System.Drawing.Size(180, 72);
            this.btnInstanciar.TabIndex = 21;
            this.btnInstanciar.Text = "Instanciar Horista";
            this.btnInstanciar.UseVisualStyleBackColor = true;
            this.btnInstanciar.Click += new System.EventHandler(this.btnInstanciar_Click);
            // 
            // txtDataentrada
            // 
            this.txtDataentrada.Location = new System.Drawing.Point(207, 208);
            this.txtDataentrada.Name = "txtDataentrada";
            this.txtDataentrada.Size = new System.Drawing.Size(100, 20);
            this.txtDataentrada.TabIndex = 19;
            // 
            // txtSalario
            // 
            this.txtSalario.Location = new System.Drawing.Point(207, 122);
            this.txtSalario.Name = "txtSalario";
            this.txtSalario.Size = new System.Drawing.Size(100, 20);
            this.txtSalario.TabIndex = 17;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(207, 79);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(224, 20);
            this.txtNome.TabIndex = 16;
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(207, 33);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(100, 20);
            this.txtMatricula.TabIndex = 15;
            // 
            // lblDataentradanaempresa
            // 
            this.lblDataentradanaempresa.AutoSize = true;
            this.lblDataentradanaempresa.Location = new System.Drawing.Point(49, 215);
            this.lblDataentradanaempresa.Name = "lblDataentradanaempresa";
            this.lblDataentradanaempresa.Size = new System.Drawing.Size(129, 13);
            this.lblDataentradanaempresa.TabIndex = 14;
            this.lblDataentradanaempresa.Text = "Dara Entrada na Empresa";
            // 
            // lblSalariohora
            // 
            this.lblSalariohora.AutoSize = true;
            this.lblSalariohora.Location = new System.Drawing.Point(49, 129);
            this.lblSalariohora.Name = "lblSalariohora";
            this.lblSalariohora.Size = new System.Drawing.Size(83, 13);
            this.lblSalariohora.TabIndex = 13;
            this.lblSalariohora.Text = "Salário por Hora";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(49, 86);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(35, 13);
            this.lblNome.TabIndex = 12;
            this.lblNome.Text = "Nome";
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Location = new System.Drawing.Point(49, 40);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(52, 13);
            this.lblMatricula.TabIndex = 11;
            this.lblMatricula.Text = "Matrícula";
            // 
            // txtNumhoras
            // 
            this.txtNumhoras.Location = new System.Drawing.Point(207, 164);
            this.txtNumhoras.Name = "txtNumhoras";
            this.txtNumhoras.Size = new System.Drawing.Size(100, 20);
            this.txtNumhoras.TabIndex = 18;
            // 
            // lblNumhoras
            // 
            this.lblNumhoras.AutoSize = true;
            this.lblNumhoras.Location = new System.Drawing.Point(49, 171);
            this.lblNumhoras.Name = "lblNumhoras";
            this.lblNumhoras.Size = new System.Drawing.Size(90, 13);
            this.lblNumhoras.TabIndex = 22;
            this.lblNumhoras.Text = "Número de Horas";
            // 
            // txtDiasdefalta
            // 
            this.txtDiasdefalta.Location = new System.Drawing.Point(207, 252);
            this.txtDiasdefalta.Name = "txtDiasdefalta";
            this.txtDiasdefalta.Size = new System.Drawing.Size(100, 20);
            this.txtDiasdefalta.TabIndex = 20;
            // 
            // lblDiasdefalta
            // 
            this.lblDiasdefalta.AutoSize = true;
            this.lblDiasdefalta.Location = new System.Drawing.Point(49, 259);
            this.lblDiasdefalta.Name = "lblDiasdefalta";
            this.lblDiasdefalta.Size = new System.Drawing.Size(74, 13);
            this.lblDiasdefalta.TabIndex = 24;
            this.lblDiasdefalta.Text = "Dias de Faltas";
            // 
            // frmHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(766, 515);
            this.Controls.Add(this.txtDiasdefalta);
            this.Controls.Add(this.lblDiasdefalta);
            this.Controls.Add(this.txtNumhoras);
            this.Controls.Add(this.lblNumhoras);
            this.Controls.Add(this.gbxHome);
            this.Controls.Add(this.btnInstanciar);
            this.Controls.Add(this.txtDataentrada);
            this.Controls.Add(this.txtSalario);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.lblDataentradanaempresa);
            this.Controls.Add(this.lblSalariohora);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblMatricula);
            this.Name = "frmHorista";
            this.Text = "frmHorista";
            this.gbxHome.ResumeLayout(false);
            this.gbxHome.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbxHome;
        private System.Windows.Forms.RadioButton rbtnNao;
        private System.Windows.Forms.RadioButton rbtnSim;
        private System.Windows.Forms.Button btnInstanciar;
        private System.Windows.Forms.TextBox txtDataentrada;
        private System.Windows.Forms.TextBox txtSalario;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.Label lblDataentradanaempresa;
        private System.Windows.Forms.Label lblSalariohora;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.TextBox txtNumhoras;
        private System.Windows.Forms.Label lblNumhoras;
        private System.Windows.Forms.TextBox txtDiasdefalta;
        private System.Windows.Forms.Label lblDiasdefalta;
    }
}