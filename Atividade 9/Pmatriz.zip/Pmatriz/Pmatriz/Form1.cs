﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;
using System.Windows.Forms;

namespace Pmatriz
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLer20_Click(object sender, EventArgs e) // Exercicio 1
        {
            int[] Vetor = new int [20];
            string aux;
            string saida = "";

            for(int i = 0; i < 20; i ++)
            {
                aux = Interaction.InputBox("Digite o número", "Entrada de Dados");
                if(!Int32.TryParse(aux, out Vetor[i]))
                {
                    MessageBox.Show("dado inválido");
                    i--;
                }
                else
                {
                    saida = Vetor[i] + "\n" + saida;
                }
            }

            MessageBox.Show(saida);
        }

        private void btnQuantMerc_Click(object sender, EventArgs e) //Exercicio 2
        {
            double[] Qtde = new double[10];
            double[] Vlr = new double[10];
            double faturamento = 0;
            string auxiliar = "";

            for (var i = 0; i < 10; i++)
            {
                auxiliar = Interaction.InputBox("Digite a quantidade da mercadoria " + (i + 1), "Entrada de Quantidade");
                
                if(!double.TryParse(auxiliar, out Qtde[i]))
                {
                    MessageBox.Show("Quantidade Inválida");
                    i--;
                }
                else
                {
                    while (Vlr[i] <= 0) // enquanto o valor digitado for menor ou igual a zero, o laço se repetira.
                    {
                        auxiliar = "";
                        auxiliar = Interaction.InputBox("Digite o valor da mercadoria " + (i + 1), "Entrada de Preços"); // somando 1 para não aparecer para o usuário a posição 0 da matriz
                        
                        if(!double.TryParse(auxiliar, out Vlr[i]))
                        {
                            MessageBox.Show("Preço Inválido");
                        }
                    }
                }
                faturamento += Qtde[i] * Vlr[i];
            }
            MessageBox.Show(faturamento.ToString("N2"));
        }

        private void btnMedia_Click(object sender, EventArgs e) // Exercicio 5
        {
            double[,] notas = new double[20, 3];
            string auxiliar;
            double media;

            for (var i = 0; i < 20; i++)
            {
                for (var j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox("Digite a nota " + (j + 1) + " do aluno " + (i + 1), "Entrada de Dados");

                    if (!double.TryParse(auxiliar, out notas[i, j])) //verificação se o usuário digitou alguma letra
                    {
                        MessageBox.Show("Nota Inválida");
                        j--;
                    }
                    else
                    {
                        if (!(notas[i, j] >= 0 && notas[i, j] <= 10)) //verificação se o usuário digitou algum número menor do que 0 ou maior do que 10
                        {
                            MessageBox.Show("Nota Inválida");
                            j--;
                        }
                    }
                }
                media = ((notas[i, 0] + notas[i, 1] + notas[i, 2]) / 3);
                MessageBox.Show("Aluno " + (i + 1) + " media: " + media.ToString("N2"));
            }
            
        }

        private void btnVaiavelTotal_Click(object sender, EventArgs e) // Exercício 3
        {
            string[] Alunos = { "Viviane", "André", "Hélio", "Denise", "Junior", "Leonardo", "Jose", "Nelma", "Toby" };

            Int32 I, N, Total;
            Total = 0;

            N = Alunos.Length;

            for(I = 0; I < N-1; I++)
            { 
                Total+= Alunos[I].Length;
                MessageBox.Show(Total.ToString("N2"));
            }    
        }

        private void btnArray_Click(object sender, EventArgs e) // Exercício 4
        {
            ArrayList ListaAlunos = new ArrayList();
            ListaAlunos.Add("Ana");
            ListaAlunos.Add("André");
            ListaAlunos.Add("Débora");
            ListaAlunos.Add("Fátima");
            ListaAlunos.Add("Janete");
            ListaAlunos.Add("Otávio");
            ListaAlunos.Add("Marcelo");
            ListaAlunos.Add("Pedro");
            ListaAlunos.Add("Thais");

            ListaAlunos.Remove("Otávio");

            foreach(string nome in ListaAlunos)
            {
                MessageBox.Show(nome);
            }
        }

        private void btnNomePessoas_Click(object sender, EventArgs e)
        {
            int RA = 4;
            string[] Nomes = new string[RA];
            int[] tamanho = new int[RA];
            string aux;

            for (var i = 0; i < RA; i++)
            {
                Nomes[i] = Interaction.InputBox((i + 1) + " Digite um nome completo: ", "Entrada de dados nomes");
                tamanho[i] = Nomes[i].Trim().Length;
            }

            lbxNomes.Items.Clear();

            for (var i = 0; i < RA; i++)
            {
                aux = "O nome: " + Nomes[i] + " tem " + tamanho[i] + " caracteres " + "\n";
                lbxNomes.Items.Add(aux);
            }

        }
    }
}

