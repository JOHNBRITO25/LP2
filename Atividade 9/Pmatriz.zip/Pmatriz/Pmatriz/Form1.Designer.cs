﻿namespace Pmatriz
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLer20 = new System.Windows.Forms.Button();
            this.btnQuantMerc = new System.Windows.Forms.Button();
            this.btnVaiavelTotal = new System.Windows.Forms.Button();
            this.btnArray = new System.Windows.Forms.Button();
            this.btnMedia = new System.Windows.Forms.Button();
            this.btnNomePessoas = new System.Windows.Forms.Button();
            this.lbxNomes = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnLer20
            // 
            this.btnLer20.Location = new System.Drawing.Point(59, 48);
            this.btnLer20.Name = "btnLer20";
            this.btnLer20.Size = new System.Drawing.Size(185, 131);
            this.btnLer20.TabIndex = 0;
            this.btnLer20.Text = "Ler 20 Numeros e Inverter";
            this.btnLer20.UseVisualStyleBackColor = true;
            this.btnLer20.Click += new System.EventHandler(this.btnLer20_Click);
            // 
            // btnQuantMerc
            // 
            this.btnQuantMerc.Location = new System.Drawing.Point(286, 48);
            this.btnQuantMerc.Name = "btnQuantMerc";
            this.btnQuantMerc.Size = new System.Drawing.Size(185, 131);
            this.btnQuantMerc.TabIndex = 1;
            this.btnQuantMerc.Text = "Ler Quant. e Preço Mercadorias";
            this.btnQuantMerc.UseVisualStyleBackColor = true;
            this.btnQuantMerc.Click += new System.EventHandler(this.btnQuantMerc_Click);
            // 
            // btnVaiavelTotal
            // 
            this.btnVaiavelTotal.Location = new System.Drawing.Point(508, 48);
            this.btnVaiavelTotal.Name = "btnVaiavelTotal";
            this.btnVaiavelTotal.Size = new System.Drawing.Size(185, 131);
            this.btnVaiavelTotal.TabIndex = 2;
            this.btnVaiavelTotal.Text = "Variável Total";
            this.btnVaiavelTotal.UseVisualStyleBackColor = true;
            this.btnVaiavelTotal.Click += new System.EventHandler(this.btnVaiavelTotal_Click);
            // 
            // btnArray
            // 
            this.btnArray.Location = new System.Drawing.Point(59, 220);
            this.btnArray.Name = "btnArray";
            this.btnArray.Size = new System.Drawing.Size(185, 131);
            this.btnArray.TabIndex = 3;
            this.btnArray.Text = "ArrayList";
            this.btnArray.UseVisualStyleBackColor = true;
            this.btnArray.Click += new System.EventHandler(this.btnArray_Click);
            // 
            // btnMedia
            // 
            this.btnMedia.Location = new System.Drawing.Point(286, 220);
            this.btnMedia.Name = "btnMedia";
            this.btnMedia.Size = new System.Drawing.Size(185, 131);
            this.btnMedia.TabIndex = 4;
            this.btnMedia.Text = "Média Alunos";
            this.btnMedia.UseVisualStyleBackColor = true;
            this.btnMedia.Click += new System.EventHandler(this.btnMedia_Click);
            // 
            // btnNomePessoas
            // 
            this.btnNomePessoas.Location = new System.Drawing.Point(508, 220);
            this.btnNomePessoas.Name = "btnNomePessoas";
            this.btnNomePessoas.Size = new System.Drawing.Size(185, 131);
            this.btnNomePessoas.TabIndex = 5;
            this.btnNomePessoas.Text = "Nomes Pessoas";
            this.btnNomePessoas.UseVisualStyleBackColor = true;
            this.btnNomePessoas.Click += new System.EventHandler(this.btnNomePessoas_Click);
            // 
            // lbxNomes
            // 
            this.lbxNomes.FormattingEnabled = true;
            this.lbxNomes.Location = new System.Drawing.Point(735, 48);
            this.lbxNomes.Name = "lbxNomes";
            this.lbxNomes.Size = new System.Drawing.Size(199, 303);
            this.lbxNomes.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(958, 415);
            this.Controls.Add(this.lbxNomes);
            this.Controls.Add(this.btnNomePessoas);
            this.Controls.Add(this.btnMedia);
            this.Controls.Add(this.btnArray);
            this.Controls.Add(this.btnVaiavelTotal);
            this.Controls.Add(this.btnQuantMerc);
            this.Controls.Add(this.btnLer20);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnLer20;
        private System.Windows.Forms.Button btnQuantMerc;
        private System.Windows.Forms.Button btnVaiavelTotal;
        private System.Windows.Forms.Button btnArray;
        private System.Windows.Forms.Button btnMedia;
        private System.Windows.Forms.Button btnNomePessoas;
        private System.Windows.Forms.ListBox lbxNomes;
    }
}

