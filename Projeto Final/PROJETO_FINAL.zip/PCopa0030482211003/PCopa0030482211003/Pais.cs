﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data;

namespace PCopa0030482211003
{
    class Pais
    {
        public int Id { get; set; }
        public string Nome { get; set; }

        public DataTable Listar()
        {
            SqlDataAdapter dataAdapterPais;

            DataTable dataTablePais = new DataTable();

            try
            {
                dataAdapterPais = new SqlDataAdapter("SELECT * FROM PAIS ORDER BY NOME", frmPrincipal.conexaoSql);
                dataAdapterPais.Fill(dataTablePais); // preencha o DataTable com os dados que foram pegos no DataAdapter
                dataAdapterPais.FillSchema(dataTablePais, SchemaType.Source);
            }
            catch (Exception)
            {
                throw;
            }

            return dataTablePais;
        }
    }
}
