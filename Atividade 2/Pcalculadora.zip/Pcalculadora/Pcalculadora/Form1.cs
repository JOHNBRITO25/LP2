﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        double numero1, numero2, resultado;

        private void btnMult_Click(object sender, EventArgs e) //MULTIPLICAÇÃO
        {
            if (double.TryParse(textBox1.Text, out numero1) && double.TryParse(textBox2.Text, out numero2))
            {
                resultado = numero1 * numero2;
                textBox3.Text = resultado.ToString("N2");
            }
        }

        private void btnDiv_Click(object sender, EventArgs e) // DIVISÃO
        {
            if (double.TryParse(textBox1.Text, out numero1) && double.TryParse(textBox2.Text, out numero2))
            {
                if ((numero1 == 0) || (numero2 == 0))
                {
                    MessageBox.Show("Operação Inválida");
                }
                else
                { 
                    resultado = numero1 / numero2;
                    textBox3.Text = resultado.ToString("N2");
                }
            }
        }

        private void btnSair_Click(object sender, EventArgs e) //SAIR
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e) //LIMPAR DADOS
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
        }

        private void btnSub_Click(object sender, EventArgs e) //SUBTRAÇÃO
        {
            if (double.TryParse(textBox1.Text, out numero1) && double.TryParse(textBox2.Text, out numero2))
            {
                resultado = numero1 - numero2;
                textBox3.Text = resultado.ToString("N2");
            }
        }

        private void btnAdi_Click(object sender, EventArgs e) //ADIÇÃO
        {
            if (double.TryParse(textBox1.Text, out numero1) && double.TryParse(textBox2.Text, out numero2))
            {
                resultado = numero1 + numero2;
                textBox3.Text = resultado.ToString("N2");
            }
        }

    }
}
